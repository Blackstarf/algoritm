#!/usr/bin/env python3
"""
ROS2 Wall Follower Node - Left-hand rule maze solver
"""
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import numpy as np
import math


class WallFollowerNode(Node):
    def __init__(self):
        super().__init__('wall_follower')
        
        # Параметры алгоритма
        self.declare_parameters(
            namespace='',
            parameters=[
                ('linear_speed', 0.28),
                ('angular_speed', 0.5),
                ('wall_distance_threshold', 0.30),
                ('front_distance_threshold', 0.27),
                ('emergency_distance', 0.15),
                ('min_distance', 0.08),
                ('move_duration', 0.7),
            ]
        )
        
        # Получаем параметры
        self.linear_speed = self.get_parameter('linear_speed').value
        self.angular_speed = self.get_parameter('angular_speed').value
        self.wall_threshold = self.get_parameter('wall_distance_threshold').value
        self.front_threshold = self.get_parameter('front_distance_threshold').value
        self.emergency_dist = self.get_parameter('emergency_distance').value
        self.min_dist = self.get_parameter('min_distance').value
        
        # Подписка на лидар
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )
        
        # Публикация команд движения
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # Таймер для основного цикла управления
        self.control_timer = self.create_timer(0.5, self.control_loop)
        
        # Данные лидара
        self.latest_scan = None
        self.scan_lock = False
        
        # Статистика
        self.stats = {
            'decisions': 0,
            'moves_forward': 0,
            'turns_left': 0,
            'turns_right': 0
        }
        
        self.get_logger().info('🤖 Wall Follower Node started - Left Hand Algorithm')
        self.get_logger().info(f'⚙️ Linear speed: {self.linear_speed} m/s')
        self.get_logger().info(f'⚙️ Angular speed: {self.angular_speed} rad/s')

    def scan_callback(self, msg: LaserScan):
        """Обработка данных лидара"""
        if not self.scan_lock:
            self.latest_scan = msg

    def get_sector_distance(self, scan: LaserScan, angle_min_deg, angle_max_deg):
        """
        Получить минимальное расстояние в секторе
        angle_min_deg, angle_max_deg: углы в градусах (0° = вперед)
        """
        if scan is None or len(scan.ranges) == 0:
            return float('inf')
        
        # Конвертируем углы в радианы
        angle_min_rad = math.radians(angle_min_deg)
        angle_max_rad = math.radians(angle_max_deg)
        
        # Определяем индексы
        total_points = len(scan.ranges)
        angle_increment = scan.angle_increment
        angle_start = scan.angle_min
        
        distances = []
        
        for i, distance in enumerate(scan.ranges):
            angle = angle_start + i * angle_increment
            
            # Нормализуем угол к [-π, π]
            angle = math.atan2(math.sin(angle), math.cos(angle))
            
            # Проверяем попадание в сектор (с учетом перехода через 0)
            if angle_min_rad > angle_max_rad:  # Переход через 0°
                if angle >= angle_min_rad or angle <= angle_max_rad:
                    if scan.range_min < distance < scan.range_max:
                        distances.append(distance)
            else:
                if angle_min_rad <= angle <= angle_max_rad:
                    if scan.range_min < distance < scan.range_max:
                        distances.append(distance)
        
        return min(distances) if distances else float('inf')

    def detect_walls(self, scan: LaserScan):
        """
        Определение наличия стен (упрощенная версия)
        Возвращает: dict с ключами 'left', 'front', 'right'
        """
        if scan is None:
            return {'left': True, 'front': True, 'right': True}
        
        # Определяем расстояния в секторах
        left_dist = self.get_sector_distance(scan, 70, 110)  # 90° ± 20°
        front_dist = self.get_sector_distance(scan, -5, 5)   # 0° ± 5°
        right_dist = self.get_sector_distance(scan, 250, 290) # 270° ± 20°
        
        walls = {
            'left': left_dist < self.wall_threshold,
            'front': front_dist < self.front_threshold,
            'right': right_dist < self.wall_threshold
        }
        
        return walls, {'left': left_dist, 'front': front_dist, 'right': right_dist}

    def check_emergency(self, distances):
        """Проверка экстренной ситуации"""
        front_dist = distances['front']
        
        if front_dist <= self.min_dist:
            return 'ABSOLUTE_STOP'
        elif front_dist <= self.emergency_dist:
            return 'EMERGENCY'
        return None

    def stop(self):
        """Остановка робота"""
        msg = Twist()
        self.cmd_vel_pub.publish(msg)

    def move_forward(self, duration=0.7):
        """Движение вперед"""
        self.get_logger().info('🔼 Moving FORWARD')
        msg = Twist()
        msg.linear.x = self.linear_speed
        self.cmd_vel_pub.publish(msg)
        self.stats['moves_forward'] += 1

    def turn_left(self):
        """Поворот налево"""
        self.get_logger().info('↩️ Turning LEFT')
        msg = Twist()
        msg.angular.z = self.angular_speed
        self.cmd_vel_pub.publish(msg)
        self.stats['turns_left'] += 1

    def turn_right(self):
        """Поворот направо"""
        self.get_logger().info('↪️ Turning RIGHT')
        msg = Twist()
        msg.angular.z = -self.angular_speed
        self.cmd_vel_pub.publish(msg)
        self.stats['turns_right'] += 1

    def move_backward(self):
        """Движение назад"""
        self.get_logger().info('🔽 Moving BACKWARD')
        msg = Twist()
        msg.linear.x = -self.linear_speed * 0.7
        self.cmd_vel_pub.publish(msg)

    def control_loop(self):
        """Основной цикл управления - Left Hand Algorithm"""
        if self.latest_scan is None:
            self.get_logger().warn('⚠️ No scan data yet')
            return
        
        self.scan_lock = True
        
        # Получаем данные о стенах
        walls, distances = self.detect_walls(self.latest_scan)
        
        # Проверяем безопасность
        emergency = self.check_emergency(distances)
        
        # Логирование
        self.get_logger().info(
            f"Walls - L:{walls['left']} F:{walls['front']} R:{walls['right']} | "
            f"Dist - L:{distances['left']:.2f} F:{distances['front']:.2f} R:{distances['right']:.2f}"
        )
        
        self.stats['decisions'] += 1
        
        # ПРИОРИТЕТ 0: ЭКСТРЕННАЯ СИТУАЦИЯ
        if emergency == 'ABSOLUTE_STOP':
            self.get_logger().error('🚨 ABSOLUTE STOP - Too close!')
            self.stop()
            self.scan_lock = False
            return
        elif emergency == 'EMERGENCY':
            self.get_logger().warn('🚨 EMERGENCY - Moving backward')
            self.move_backward()
            self.scan_lock = False
            return
        
        # АЛГОРИТМ ЛЕВОЙ РУКИ
        decision_made = False
        
        # 1. ПРИОРИТЕТ: ПОВЕРНУТЬ НАЛЕВО (если слева нет стены)
        if not walls['left']:
            self.get_logger().info('🎯 DECISION: Turn LEFT (priority 1)')
            self.turn_left()
            decision_made = True
        
        # 2. ПРИОРИТЕТ: ДВИГАТЬСЯ ВПЕРЕД (если нельзя налево, но можно вперед)
        elif not decision_made and not walls['front']:
            self.get_logger().info('🎯 DECISION: Move FORWARD (priority 2)')
            self.move_forward()
            decision_made = True
        
        # 3. ПРИОРИТЕТ: ПОВЕРНУТЬ НАПРАВО (если нельзя налево и вперед)
        elif not decision_made and not walls['right']:
            self.get_logger().info('🎯 DECISION: Turn RIGHT (priority 3)')
            self.turn_right()
            decision_made = True
        
        # 4. ПРИОРИТЕТ: РАЗВОРОТ (тупик)
        elif not decision_made:
            self.get_logger().warn('🎯 DECISION: U-TURN (dead end)')
            self.turn_right()
            decision_made = True
        
        self.scan_lock = False

    def shutdown(self):
        """Завершение работы"""
        self.get_logger().info('🛑 Shutting down Wall Follower')
        self.stop()
        self.get_logger().info(f'📊 Stats - Decisions: {self.stats["decisions"]}, '
                              f'Forward: {self.stats["moves_forward"]}, '
                              f'Left: {self.stats["turns_left"]}, '
                              f'Right: {self.stats["turns_right"]}')


def main(args=None):
    rclpy.init(args=args)
    node = WallFollowerNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.shutdown()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
