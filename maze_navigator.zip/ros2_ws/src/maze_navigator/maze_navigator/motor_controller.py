#!/usr/bin/env python3
"""
ROS2 Motor Controller Node - ESP32 interface
Subscribes to /cmd_vel and sends commands to ESP32
"""
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial
import json
import time


class MotorControllerNode(Node):
    def __init__(self):
        super().__init__('motor_controller')
        
        # Параметры
        self.declare_parameters(
            namespace='',
            parameters=[
                ('esp32_port', '/dev/ttyACM1'),
                ('baudrate', 115200),
                ('wheel_base', 0.15),  # расстояние между колесами (м)
                ('wheel_radius', 0.05),  # радиус колеса (м)
                ('max_speed', 500),  # максимальная скорость мотора
            ]
        )
        
        # Получаем параметры
        esp32_port = self.get_parameter('esp32_port').value
        baudrate = self.get_parameter('baudrate').value
        self.wheel_base = self.get_parameter('wheel_base').value
        self.wheel_radius = self.get_parameter('wheel_radius').value
        self.max_speed = self.get_parameter('max_speed').value
        
        # Подключение к ESP32
        try:
            self.serial = serial.Serial(esp32_port, baudrate=baudrate, timeout=1)
            time.sleep(2)  # Ждем инициализацию
            self.get_logger().info(f'🤖 Connected to ESP32 on {esp32_port}')
        except Exception as e:
            self.get_logger().error(f'❌ Failed to connect to ESP32: {e}')
            self.serial = None
        
        # Подписка на команды движения
        self.cmd_vel_sub = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_vel_callback,
            10
        )
        
        # Таймер для остановки при отсутствии команд
        self.last_cmd_time = self.get_clock().now()
        self.timeout_timer = self.create_timer(0.5, self.check_timeout)
        self.cmd_timeout = 1.0  # секунды
        
        self.get_logger().info('✅ Motor Controller Node started')

    def twist_to_motor_speeds(self, linear_x, angular_z):
        """
        Конвертация Twist в скорости моторов для mecanum/omni wheels
        
        Для 4-колесного робота с mecanum/omni колесами:
        - M1: передний левый
        - M2: передний правый  
        - M3: задний правый
        - M4: задний левый
        """
        # Базовая скорость от линейного движения
        base_speed = (linear_x / self.wheel_radius) * self.max_speed / 10.0
        
        # Добавка от вращения
        rotation_speed = (angular_z * self.wheel_base / self.wheel_radius) * self.max_speed / 10.0
        
        # Для differential drive (как в твоем коде):
        # Вперед: все колеса вперед
        # Поворот: левые и правые в противоположные стороны
        
        if abs(angular_z) > 0.01:  # Поворот
            if angular_z > 0:  # Налево
                m1 = -rotation_speed
                m2 = rotation_speed
                m3 = rotation_speed
                m4 = -rotation_speed
            else:  # Направо
                m1 = rotation_speed
                m2 = -rotation_speed
                m3 = -rotation_speed
                m4 = rotation_speed
        else:  # Прямое движение
            m1 = base_speed
            m2 = base_speed
            m3 = base_speed
            m4 = base_speed
        
        # Ограничиваем скорости
        speeds = [m1, m2, m3, m4]
        max_abs_speed = max([abs(s) for s in speeds])
        
        if max_abs_speed > self.max_speed:
            scale = self.max_speed / max_abs_speed
            speeds = [s * scale for s in speeds]
        
        return [int(s) for s in speeds]

    def send_command(self, m1, m2, m3, m4):
        """Отправка команды моторам через ESP32"""
        if not self.serial or not self.serial.is_open:
            return False
        
        try:
            cmd = {
                "T": 11,
                "M1": int(m1),
                "M2": int(m2),
                "M3": int(m3),
                "M4": int(m4)
            }
            json_cmd = json.dumps(cmd) + '\n'
            self.serial.write(json_cmd.encode())
            self.serial.flush()
            return True
        except Exception as e:
            self.get_logger().error(f'❌ Error sending command: {e}')
            return False

    def cmd_vel_callback(self, msg: Twist):
        """Обработка команд движения"""
        self.last_cmd_time = self.get_clock().now()
        
        linear_x = msg.linear.x
        angular_z = msg.angular.z
        
        # Конвертируем в скорости моторов
        m1, m2, m3, m4 = self.twist_to_motor_speeds(linear_x, angular_z)
        
        # Отправляем команду
        success = self.send_command(m1, m2, m3, m4)
        
        if success:
            self.get_logger().debug(
                f'Motors: M1={m1}, M2={m2}, M3={m3}, M4={m4} '
                f'(linear={linear_x:.2f}, angular={angular_z:.2f})'
            )

    def check_timeout(self):
        """Проверка таймаута команд - остановка если давно не было команд"""
        time_since_cmd = (self.get_clock().now() - self.last_cmd_time).nanoseconds / 1e9
        
        if time_since_cmd > self.cmd_timeout:
            # Останавливаем моторы
            self.send_command(0, 0, 0, 0)

    def stop(self):
        """Остановка моторов"""
        self.get_logger().info('🛑 Stopping motors')
        self.send_command(0, 0, 0, 0)

    def shutdown(self):
        """Завершение работы"""
        self.stop()
        if self.serial and self.serial.is_open:
            self.serial.close()
        self.get_logger().info('👋 Motor Controller shutdown')


def main(args=None):
    rclpy.init(args=args)
    node = MotorControllerNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.shutdown()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
