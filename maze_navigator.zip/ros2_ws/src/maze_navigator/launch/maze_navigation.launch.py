from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
import os
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # Путь к конфигу
    config_file = os.path.join(
        get_package_share_directory('maze_navigator'),
        'config',
        'params.yaml'
    )
    
    return LaunchDescription([
        # LD19 Lidar
        Node(
            package='ldlidar_stl_ros2',
            executable='ldlidar_stl_ros2_node',
            name='ldlidar',
            output='screen',
            parameters=[{
                'product_name': 'LDLiDAR_LD19',
                'topic_name': 'scan',
                'frame_id': 'base_laser',
                'port_name': '/dev/lidar',
                'port_baudrate': 230400,
                'laser_scan_dir': True,
                'enable_angle_crop_func': False,
                'angle_crop_min': 0.0,
                'angle_crop_max': 360.0,
            }]
        ),
        
        # Motor Controller
        Node(
            package='maze_navigator',
            executable='motor_controller',
            name='motor_controller',
            output='screen',
            parameters=[config_file]
        ),
        
        # Wall Follower
        Node(
            package='maze_navigator',
            executable='wall_follower',
            name='wall_follower',
            output='screen',
            parameters=[config_file]
        ),
    ])
